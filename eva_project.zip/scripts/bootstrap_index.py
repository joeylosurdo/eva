# Dummy content for bootstrap_index.py
