# Dummy content for embedder.py
